# About

+ This is a mod for the game [Factorio](https://www.factorio.com/).
+ You can download the mod at [mods.factorio.com](https://mods.factorio.com/mods/MarcGamesons/cheaper_landfill).
+ Forum topic: https://forums.factorio.com/viewtopic.php?f=93&t=44991

## License
This modification for the game Factorio is licensed under the [MIT License](https://opensource.org/licenses/MIT).
